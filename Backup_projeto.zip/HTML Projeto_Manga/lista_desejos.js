function expandir(x){
    x.style.width = "124px";
}
function diminuir(x){
    x.style.width = "120px";
}   
function expandir1(x){
    x.style.fontSize = "32px";
}
function diminuir1(x){
    x.style.fontSize = "30px";
}   